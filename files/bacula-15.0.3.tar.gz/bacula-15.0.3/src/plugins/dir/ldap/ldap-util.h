/*
   Bacula(R) - The Network Backup Solution

   Copyright (C) 2000-2025 Kern Sibbald

   The original author of Bacula is Kern Sibbald, with contributions
   from many others, a complete list can be found in the file AUTHORS.

   You may use this file and others of this release according to the
   license defined in the LICENSE file, which includes the Affero General
   Public License, v3.0 ("AGPLv3") and some additional permissions and
   terms pursuant to its AGPLv3 Section 7.

   This notice must be preserved when any source code is
   conveyed and/or propagated.

   Bacula(R) is a registered trademark of Kern Sibbald.
*/
/*
 * Common definitions and utility functions for Inteos plugins.
 * Functions defines a common framework used in our utilities and plugins.
 * LDAP plugin specific functions.
 *
 * Author: Radosław Korzeniewski, radoslaw@korzeniewski.net, Inteos Sp. z o.o.
 */

#ifndef _LDAP_UTIL_H_
#define _LDAP_UTIL_H_

#include "bacula.h"
#include "dir_plugins.h"

#ifdef __WIN32__
#include <winldap.h>
#else
#include <ldap.h>
#endif

/* Plugin compile time variables */
#define PLUGINPREFIX                "ldap:"
#define PLUGINNAME                  "LDAP"

typedef struct s_ldap_paramlist {
   const char *ldapuri;
   const char *binddn;
   char *bindpass;
   bool starttls;
   bool starttlsforce;
} ldap_paramlist;

/* util definitions */
LDAP * ldapconnect(bpContext * ctx, ldap_paramlist * paramlist);
int ldapdisconnect(bpContext * ctx, LDAP * ld);
bool ldapcheckonedn(bpContext * ctx, LDAP * ld, char *dn);

#endif               /* _LDAP_UTIL_H_ */
